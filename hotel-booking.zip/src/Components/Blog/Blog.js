import React from 'react';

const Blog = () => {
    return (
        <div>
            <div className="pt-5 mt-5">
                 <h1 className="mt-5 text-center text-success">Blog page is not completed . Soon It will be completed</h1>
             </div>
        </div>
    );
};

export default Blog;