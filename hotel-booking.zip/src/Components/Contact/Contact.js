import React from 'react';

const Contact = () => {
    return (
        <div className="pt-5 mt-5">
            <h1 className="mt-5 text-center text-success">Contact page is not completed . Soon It will be completed</h1>
        </div>
    );
};

export default Contact;