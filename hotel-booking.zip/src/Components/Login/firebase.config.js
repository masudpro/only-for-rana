const firebaseConfig = {
    apiKey: "AIzaSyCz9j5i97iAawu2oKQpCyt0WFALuHi_j9M",
    authDomain: "hotel-booking-b9959.firebaseapp.com",
    databaseURL: "https://hotel-booking-b9959.firebaseio.com",
    projectId: "hotel-booking-b9959",
    storageBucket: "hotel-booking-b9959.appspot.com",
    messagingSenderId: "517520777532",
    appId: "1:517520777532:web:442673a63aa4152277be39"
  };

  export default firebaseConfig;