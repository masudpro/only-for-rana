import React from 'react';

const NoFound = () => {
    return (
        <div className="pt-5 mt-5">
            <h1 className="mt-5 text-center text-warning">Sorry This Page is Not Found</h1>
        </div>
    );
};

export default NoFound;