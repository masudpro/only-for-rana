var coxbazar = [
	{  
		name: 'Right Side Room with green View',
		place: 'coxbazar',
		id: 'coxbazar1',
		guests: '4',
		bedrooms: '2',
		bed: '2',
		bathrooms: '2',
		cost: '34',
		ratting: '4.8',
		rattingNumber: '20',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Light House, full lighing view View',
		place: 'coxbazar',
		id: 'coxbazar2',
		guests: '5',
		bedrooms: '3',
		bed: '2',
		bathrooms: '2',
		cost: '35',
		ratting: '4.5',
		rattingNumber: '13',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Glass wall with swimming pole and chair',
		place: 'coxbazar',
		id: 'coxbazar3',
		guests: '2',
		bedrooms: '1',
		bed: '1',
		bathrooms: '1',
		cost: '64',
		ratting: '4.3',
		rattingNumber: '22',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1553653924-39b70295f8da?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Left Room with see View and swimming pool',
		place: 'coxbazar',
		id: 'coxbazar4',
		guests: '6',
		bedrooms: '3',
		bed: '3',
		bathrooms: '2',
		cost: '56',
		ratting: '4.7',
		rattingNumber: '45',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1540541338287-41700207dee6?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{	place: 'coxbazar',
		placeName: "cox's bazar",
		placeId: 'placeCoxbazar',
		placeDescription: "Cox’s Bazar is a town on the southeast coast of Bangladesh. It’s known for its very long, sandy beachfront, stretching from Sea Beach in the north to Kolatoli Beach in the south. Aggameda Khyang monastery is home to bronze statues and centuries-old Buddhist manuscripts. South of town, the tropical rainforest of Himchari National Park has waterfalls and many birds. North, sea turtles breed on nearby Sonadia Island.",

		googleMap: "https://maps.google.com/maps?q=Cox's+Bazar,+Bangladesh&output=embed"
	},
	

	
	


]
export default coxbazar;