import sundarbans from './sundarbans';
import sreemangal from './sreemangal';
import coxbazar from './coxbazar';

const placeData = [...sundarbans, ...sreemangal, ...coxbazar];



export default placeData;