var sreemangal = [
	{  
		name: 'Blue pavilion with swimming pole with sky View',
		place: 'sreemangal',
		id: 'sreemangal1',
		guests: '4',
		bedrooms: '2',
		bed: '2',
		bathrooms: '2',
		cost: '68',
		ratting: '4.8',
		rattingNumber: '20',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1455587734955-081b22074882?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Full sky view, enjoy moon light and view green',
		place: 'sreemangal',
		id: 'sreemangal2',
		guests: '5',
		bedrooms: '3',
		bed: '2',
		bathrooms: '2',
		cost: '35',
		ratting: '4.5',
		rattingNumber: '13',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'swimming pole and chair, and drinking coconut',
		place: 'sreemangal',
		id: 'sreemangal3',
		guests: '2',
		bedrooms: '1',
		bed: '1',
		bathrooms: '1',
		cost: '64',
		ratting: '4.3',
		rattingNumber: '22',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1498503182468-3b51cbb6cb24?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Font room of motel, see View and swimming pool',
		place: 'sreemangal',
		id: 'sreemangal4',
		guests: '6',
		bedrooms: '3',
		bed: '3',
		bathrooms: '2',
		cost: '34',
		ratting: '4.7',
		rattingNumber: '45',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{
		place: 'sreemangal',
		placeName: 'sreeMangal',
		placeId: 'placeSreeMangal',
		placeDescription: "It is said the name Sreemangal (or Srimangal) is named after Sri Das and Mangal Das; two brothers who settled on the banks of the Hail Haor.[2] A copper plate of Raja Marundanath from the 11th century was found in Kalapur. During an excavation at Lamua, an ancient statue of Ananta Narayan was dug out. In 1454, the Nirmai Shiva Bari was built and still stands today. Srimangal thana was established in 1912. The central town later became a pourashava in 1935. In 1963, two peasants were killed by police officers which kicked off the Balishira peasant riots. During the Bangladesh Liberation War of 1971, the Pakistani army reached Srimangal on 30 April setting houses on fire and committing atrocities against women. The East Pakistan Rifles camp and Wapda office premises were among the two mass killing sites. Two mass graves remain in Bharaura with a memorial in North Bharaura.",

		googleMap: "https://maps.google.com/maps?q=Sreemangal,+Bangladesh&output=embed"
	},
	


]
export default sreemangal;