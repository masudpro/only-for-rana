var sundarbans = [
	{  
		name: 'Lighting room with green View and moon light',
		place: 'sundarbans',
		id: 'sundarbans1',
		guests: '4',
		bedrooms: '2',
		bed: '2',
		bathrooms: '2',
		cost: '68',
		ratting: '4.8',
		rattingNumber: '20',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1445019980597-93fa8acb246c?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Green View, tree and moon light with see view',
		place: 'sundarbans',
		id: 'sundarbans2',
		guests: '5',
		bedrooms: '3',
		bed: '2',
		bathrooms: '2',
		cost: '35',
		ratting: '4.5',
		rattingNumber: '13',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1582719508461-905c673771fd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'Full wood room with candle light and eat village food',
		place: 'sundarbans',
		id: 'sundarbans3',
		guests: '2',
		bedrooms: '1',
		bed: '1',
		bathrooms: '1',
		cost: '44',
		ratting: '4.3',
		rattingNumber: '22',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{  
		name: 'East view with full sky view, mid night view ',
		place: 'sundarbans',
		id: 'sundarbans4',
		guests: '6',
		bedrooms: '3',
		bed: '3',
		bathrooms: '2',
		cost: '95',
		ratting: '4.7',
		rattingNumber: '45',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		image: 'https://images.unsplash.com/photo-1529290130-4ca3753253ae?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60'
	},
	{	place: 'sundarbans',
		placeName: 'SundarBans',
		placeId: 'placeSundarBans',
		placeDescription: "The Sundarbans is a mangrove area in the delta formed by the confluence of the Ganges, Brahmaputra and Meghna Rivers in the Bay of Bengal. It spans from the Hooghly River in India's state of West Bengal to the Baleswar River in Bangladesh.",
		googleMap: "https://maps.google.com/maps?q=Sundarban,+Bangladesh&output=embed"
	},
	


]
export default sundarbans;