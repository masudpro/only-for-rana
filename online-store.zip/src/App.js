import React from 'react';
import './App.css';
import Shop from './Components/Shop/Shop';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import Header from './Components/Header/Header';
import Cart from './Components/Cart/Cart';
import ProductDetails from './Components/ProductDetails/ProductDetails';
import Footer from './Components/Footer/Footer';
import Notfound from './Components/Notfound/Notfound';
import Category from './Components/Category/Category';

function App() {
  return (
    <div className="App">
       <Router>
      <Header></Header>
        <Switch>
          <Route path="/shop" >
              <Shop></Shop>
          </Route>
          <Route path="/cart" >
             <Cart></Cart>
          </Route>
          <Route path="/category/:productCategory" >
             <Category></Category>
          </Route>
          <Route path="/product/:productId" >
             <ProductDetails></ProductDetails>
          </Route>
          <Route path="/" >
              <Shop></Shop>
          </Route>
          <Route path="*" >
           <Notfound></Notfound>
          </Route>
          {/* <PrivateRoute path="/inventory" >
            <Inventory></Inventory>
          </PrivateRoute> */}
          
          {/* <Route exact path="/product/:productkey" >
              <ProductDetail></ProductDetail>
          </Route>
           */}
        </Switch>
      </Router>
      <Footer></Footer>
    </div>
  );
}

export default App;
