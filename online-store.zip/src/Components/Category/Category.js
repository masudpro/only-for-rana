import React, { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import allProducts from '../products';



const Category = () => {
    const {productCategory} = useParams();
    const [categoryProduct, setCategoryProduct] = useState([]);
    
    useEffect(()=> {
         const product = allProducts.filter( pd => pd.category === productCategory);
         setCategoryProduct(product)
    }, [])


    
    console.log('catProduct = ', categoryProduct);

   
    return (
        <div className="container">

            

            <div className="row">

           
            {
                categoryProduct.map ( categoryProduct => 
                 <div key ={ categoryProduct.name} className="col-6 col-md-3" >
                     <div className="text-center  bg-success mb-4">
                     <img className="img-fluid" src={categoryProduct.image} alt=""/>
                         <a href=""><h1 className="productName">{categoryProduct.name}</h1></a>
                         <h1 className="productPrice"><span>{categoryProduct.price}</span></h1>
                        <h1 className="productName">{categoryProduct.name}</h1>
                     </div>
                </div>
                )
            } 
            </div>
        </div>
    );
};

export default Category;