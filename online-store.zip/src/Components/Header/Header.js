import React from 'react';
import { Link, useHistory } from 'react-router-dom';

const Header = () => {

    // const history = useHistory();
    // const handleClick = () => {
    //     history.push(`/category/shirt`)
    // }
    // const handleClickp = () => {
    //     history.push(`/category/pant`)
    // }
     return (
        
        <div>

<div className="category text-center col-12 bg-success mb-4">
                   
                   <div className="text-center p-3  bg-success mb-4">
                       <Link className="bg-light p-3 mx-1" to={"/category/shirt"}> Shirt </Link>
                       <Link className="bg-light p-3 mx-1" to={"/category/t-shirt"}> T Shirt </Link>
                       <Link className="bg-light p-3 mx-1" to={"/category/pant"}> Pant </Link>
                       <Link className="bg-light p-3 mx-1" to={"/category/coat"}> Coat </Link>
                   </div>
           
       </div>

            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item">
                            <Link to="/shop" className="nav-link" >Products</Link>
                        </li>
                        <li className="nav-item">
                            <Link to="/cart" className="nav-link" >Cart</Link>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    );
};

export default Header;