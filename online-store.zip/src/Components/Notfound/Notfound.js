import React from 'react';

const Notfound = () => {
    return (
        <div>
            <h2>This Page Not Found</h2>
        </div>
    );
};

export default Notfound;