import React from 'react';
import { useParams } from 'react-router-dom';
import allProducts from '../products';

const ProductDetails = () => {
    const {productId} = useParams();
    const product = allProducts.find( pd => pd.id === productId);
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-6">
                        <img src={product.image} alt=""/>
                </div>
                <div className="col-md-6">
                    <h1>{product.name}</h1>
                    <h1>{product.price} </h1>
                    <h6><span> Minus </span> <input style={{width: '80px'}} type="number"/> <span>Add</span> </h6>
                    <button> Add To Cart </button>
                    <p>{product.description} {product.description}</p>
                </div>
            </div>
            
        </div>
    );
};

export default ProductDetails;