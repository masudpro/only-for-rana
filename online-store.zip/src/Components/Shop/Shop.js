import React, { useState } from 'react';
import './Shop.css'
import allProducts from '../products';
import { Link } from 'react-router-dom';

const Shop = () => {
    const [produts, setProduts] = useState(allProducts);
   console.log(produts)
    return (
        <div className="container">
            <div className="row">
               
            
            {
                produts.map ( produts => 
                 <div key ={ produts.name} className="col-6 col-md-3" >
                     <div className="text-center  bg-success mb-4">
                        <img className="img-fluid" src={produts.image} alt=""/>
                         <a href=""><h1 className="productName">{produts.name}</h1></a>
                         <h1 className="productPrice"><span>{produts.price}</span></h1>
                        
                         <Link to={"/product/"+produts.id}> View Details </Link>
                     </div>
                </div>
                )
            }
  
            </div>
        </div>
    );
};

export default Shop;