var coatApi = [
	{  
		name: 'coat one Ab 345',
		category: 'coat',
		id: 'coat1',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '60',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(1).png'
	},
	{  
		name: 'coat two cd 433',
		category: 'coat',
		id: 'coat2',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '80',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(2).png'
	},
	{  
		name: 'coat three jk 345',
		category: 'coat',
		id: 'coat3',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '40',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(3).png'
	},
	{  
		name: 'coat one rfg 977',
		category: 'coat',
		id: 'coat4',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '64',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(4).png'
	},
	{  
		name: 'coat one xhf 759',
		category: 'coat',
		id: 'coat5',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '76',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(5).png'
	},
	{  
		name: 'coat one kun 086',
		category: 'coat',
		id: 'coat6',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '48',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(6).png'
	},
	{  
		name: 'coat one jhf 356',
		category: 'coat',
		id: 'coat7',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '89',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(7).png'
	},
	{  
		name: 'coat one hdr 567',
		category: 'coat',
		id: 'coat8',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '57',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/coat(8).png'
	},
	


]
export default coatApi;