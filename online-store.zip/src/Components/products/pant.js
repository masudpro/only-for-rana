var pantApi = [
	{  
		name: 'pant one Ab 345',
		category: 'pant',
		id: 'pant1',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '60',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(1).png'
	},
	{  
		name: 'pant two cd 433',
		category: 'pant',
		id: 'pant2',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '80',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(2).png'
	},
	{  
		name: 'pant three jk 345',
		category: 'pant',
		id: 'pant3',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '40',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(3).png'
	},
	{  
		name: 'pant one rfg 977',
		category: 'pant',
		id: 'pant4',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '64',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(4).png'
	},
	{  
		name: 'pant one xhf 759',
		category: 'pant',
		id: 'pant5',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '76',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(5).png'
	},
	{  
		name: 'pant one kun 086',
		category: 'pant',
		id: 'pant6',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '48',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(6).png'
	},
	{  
		name: 'pant one jhf 356',
		category: 'pant',
		id: 'pant7',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '89',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(7).png'
	},
	{  
		name: 'pant one hdr 567',
		category: 'pant',
		id: 'pant8',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '57',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/pant(8).png'
	},
	


]
export default pantApi;