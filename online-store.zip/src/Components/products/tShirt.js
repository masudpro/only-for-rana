var tShirtApi = [
	{  
		name: 't-shirt one Ab 345',
		category: 't-shirt',
		id: 't-shirt1',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '60',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(1).png'
	},
	{  
		name: 't-shirt two cd 433',
		category: 't-shirt',
		id: 't-shirt2',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '80',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(2).png'
	},
	{  
		name: 't-shirt three jk 345',
		category: 't-shirt',
		id: 't-shirt3',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '40',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(3).png'
	},
	{  
		name: 't-shirt one rfg 977',
		category: 't-shirt',
		id: 't-shirt4',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '64',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(4).png'
	},
	{  
		name: 't-shirt one xhf 759',
		category: 't-shirt',
		id: 't-shirt5',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '76',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(5).png'
	},
	{  
		name: 't-shirt one kun 086',
		category: 't-shirt',
		id: 't-shirt6',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '48',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(6).png'
	},
	{  
		name: 't-shirt one jhf 356',
		category: 't-shirt',
		id: 't-shirt7',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '89',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(7).png'
	},
	{  
		name: 't-shirt one hdr 567',
		category: 't-shirt',
		id: 't-shirt8',
		description: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
		price: '57',
		image: 'https://raw.githubusercontent.com/masudpro/ecommercePhotoForWeb/master/t-shirt(8).png'
	},
	


]
export default tShirtApi;